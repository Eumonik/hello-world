function runit(blam)

    {
      var alpha = /^[a-zA-Z]+$/;
      var alphanum = /^[0-9a-zA-Z]+$/;
      var emailx = /^.+@.+$/;
      var first = blam.fname.value;
      var last = blam.lname.value;
      var address = blam.address.value;
      var city = blam.city.value;
      var state = blam.state.value;
      var acode = blam.acode.value;
      var number = blam.number.value;
      var email = blam.email.value;
      var meal = blam.meal.value;

      if (first == "")
      {
        alert("FIRST NAME NEEDED");
      }
     }
